long maxu=16;

delu2()
{
	bprintf("Selection from main menu only\n");
}


chpwd()
{
	bprintf("To change your password select option 2 from the main menu\n");
}

debug2()
{
	bprintf("No debugger available\n");
}

