#include <stdio.h>
#include "System.h"

/*
 *	Code for doing hardware windowed output on BBC GTSS terminals
 *		Removed on UNIX version
 *
 */
 
long tty;		/* TTY Type - not used either */
 
void initscr()
{
	;
}

void topscr()
{
	;
}

void btmscr()
{
	;
}

