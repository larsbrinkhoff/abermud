struct objectitem
{
	char *o_name;
	char *o_desc[4];
	long o_maxstate;
	long o_value;
	long o_flannel;
};

typedef struct objectitem OBJECT;

